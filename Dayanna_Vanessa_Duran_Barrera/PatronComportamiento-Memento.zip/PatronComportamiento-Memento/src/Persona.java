/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DD
 */
public class Persona {
    
    private String nombre;
    
    public EjemploMemento saveToMemento(){
        System.out.println("Originador: Guardando Memento...");
        return new EjemploMemento(nombre);
    }
    
    public void restoreFromMemento(EjemploMemento m){
        nombre=m.getSavedState();
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
}
