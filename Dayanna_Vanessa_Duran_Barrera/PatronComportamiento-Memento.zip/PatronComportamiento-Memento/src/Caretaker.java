
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DD
 */
public class Caretaker {
    
    private ArrayList<EjemploMemento>estados=new ArrayList<EjemploMemento>();
    
    public void addMemento (EjemploMemento m){
        estados.add(m);
    }
    
    public EjemploMemento getMemento(int index){
        return estados.get(index);
    }
    
    public static void main(String[] args) {
    Caretaker caretaker=new Caretaker();
        
    Persona p=new Persona();
    p.setNombre("Miguel");
    p.setNombre("Julian");
    
    caretaker.addMemento(p.saveToMemento());
    
    p.setNombre("Pablo");
    
    caretaker.addMemento(p.saveToMemento());
    
    p.setNombre("David");
    
    EjemploMemento m1=caretaker.getMemento(0);
    EjemploMemento m2=caretaker.getMemento(1);
    
        System.out.println(m1.getSavedState());
        System.out.println(m2.getSavedState());
        
    }
 
}

