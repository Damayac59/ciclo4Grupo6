/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronestructural.flyweight;

/**
 *
 * @author dayan
 */
public class Main {
    
    public static void main(String[] args) {
        
        double promedioGeneral=6;
        
        String nombres[]={"Julian","Miguel","Pablo"};
        String apellidos[]={"Petro","Laso","Mendez"};
        double promedios[]={6,7,9};
        
        Alumno alumno=new Alumno(promedioGeneral);
        for (int i = 0; i < nombres.length; i++) {
            alumno.setNombre(nombres[i]);
            alumno.setApellido(apellidos[i]);
            alumno.setPromedio(promedios[i]);
            System.out.println(nombres[i]+ ":"+ alumno.compara());
        }
    }
}
