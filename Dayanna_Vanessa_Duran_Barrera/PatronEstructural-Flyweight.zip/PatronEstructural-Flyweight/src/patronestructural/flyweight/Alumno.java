/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronestructural.flyweight;

/**
 *
 * @author DD
 */
public class Alumno {

    private String nombre;
    private String apellido;
    private double promedio;
    private double promedioGeneral;
    
    public Alumno(double promedioGeneral){
        setPromedioGeneral(promedioGeneral);
    }
    
    public double compara(){
        return (((double)promedio)/promedioGeneral-1)*100;
    }

    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public void setPromedioGeneral(double promedioGeneral) {
        this.promedioGeneral = promedioGeneral;
    }

    public double getPromedioGeneral() {
        return promedioGeneral;
    }
    
    
    public Alumno(String nombre, String apellido, double promedio, double promedioGeneral) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.promedio = promedio;
        this.promedioGeneral = promedioGeneral;
    }

 
}

