function idusuario_vali(idusuario){
    alert("metodo js "+idusuario)
    if(isNaN(idusuario)){
        alert("el valor " + idusuario + " NO es valido");
        return "el valor " + idusuario + " NO es valido";
    }
    else{
        alert("el valor "+ idusuario + " es valido");
        return "";
    }
}

function mensaje(){
    alert("Bienvenido Colaborador");

    var button1 = document.getElementById("button1")
    var button2 = document.getElementById("button2")
      
    button1.addEventListener('onmouseover', function(){
        alert("Registre novedad")
        window.location("Registre_Novedad.html")
    })
      
    button2.addEventListener('click', function(){
        alert("Feliz dia")
    })    
}
  
function usrpas(){
    if (document.login.username.value=="admin" && document.login.password.value=="1234")
   { alert("Bienvenido.");
   window.location="Home_Administrador.html"
    }
    else {alert("Error en Usuario o Contraseña. Intenta de nuevo.")}
    }
  document.oncontextmenu=new Function("return false");

