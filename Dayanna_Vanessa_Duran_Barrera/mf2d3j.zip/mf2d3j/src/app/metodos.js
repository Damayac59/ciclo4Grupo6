function mensaje(){
    alert("Bienvenido Colaborador");

    var button1 = document.getElementById("button1")
    var button2 = document.getElementById("button2")
      
    button1.addEventListener('onmouseover', function(){
        alert("Registre novedad")
        window.location("Registre_Novedad.html")
    })
      
    button2.addEventListener('click', function(){
        alert("Feliz dia")
    })    
}
  