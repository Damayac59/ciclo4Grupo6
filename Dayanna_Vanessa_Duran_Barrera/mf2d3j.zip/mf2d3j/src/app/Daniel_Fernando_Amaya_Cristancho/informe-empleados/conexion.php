<?php
$user='root';
$password='';
$db="mf2dej";

$db =new mysql('localhost',$user,$password,$db), or die("no se pudo conectar a la base de datos");


?>