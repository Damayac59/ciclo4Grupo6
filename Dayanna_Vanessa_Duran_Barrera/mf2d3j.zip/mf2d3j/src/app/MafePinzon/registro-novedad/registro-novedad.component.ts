import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-novedad',
  templateUrl: './registro-novedad.component.html',
  styleUrls: ['./registro-novedad.component.css']
})
export class RegistroNovedadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
