import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroNovedadComponent } from './registro-novedad.component';

describe('RegistroNovedadComponent', () => {
  let component: RegistroNovedadComponent;
  let fixture: ComponentFixture<RegistroNovedadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistroNovedadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistroNovedadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
