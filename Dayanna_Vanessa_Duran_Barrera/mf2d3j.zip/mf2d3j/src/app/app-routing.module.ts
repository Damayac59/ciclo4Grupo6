import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeAdministradorComponent } from './Dayanna_Duran/home-administrador/home-administrador.component';
import { NuevoUsuarioComponent } from './JorgeRodriguez/nuevo-usuario/nuevo-usuario.component';
import { CrearNovedadesComponent } from './MafeOlaya/crear-novedades/crear-novedades.component';
import { InformeEmpleadosComponent } from './Daniel_Fernando_Amaya_Cristancho/informe-empleados/informe-empleados.component';
import { PaginaPrincipalComponent } from './DanielTesillo/pagina-principal/pagina-principal.component';
import { HomeEmpleadoComponent } from './Dayanna_Duran/home-empleado/home-empleado.component';
import { RegistroNovedadComponent } from './MafePinzon/registro-novedad/registro-novedad.component';
import { Pagina404Component } from './Dayanna_Duran/pagina404/pagina404.component';
import { EliminarNovedadComponent } from './MafeOlaya/eliminar-novedad/eliminar-novedad.component';


const routes: Routes = [

  {path: '', component: HomeAdministradorComponent},
  {path: 'home-administrador', component: HomeAdministradorComponent},
  {path: 'nuevo-usuario', component: NuevoUsuarioComponent},
  {path: 'crear-novedad', component: CrearNovedadesComponent},
  {path: 'eliminar-novedad', component: EliminarNovedadComponent},
  {path: 'informe-empleados', component: InformeEmpleadosComponent},
  {path: 'pagina-principal', component: PaginaPrincipalComponent},
  {path: '', component: HomeEmpleadoComponent},
  {path: 'home-empleado', component: HomeEmpleadoComponent},
  {path: 'registro-novedad', component: RegistroNovedadComponent},
  {path: '**', component: Pagina404Component},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
