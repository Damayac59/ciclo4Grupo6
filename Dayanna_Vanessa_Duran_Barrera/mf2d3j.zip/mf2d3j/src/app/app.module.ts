import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HomeAdministradorComponent } from './Dayanna_Duran/home-administrador/home-administrador.component';
import { HomeEmpleadoComponent } from './Dayanna_Duran/home-empleado/home-empleado.component';
import { Pagina404Component } from './Dayanna_Duran/pagina404/pagina404.component';
import { ServiciogeneralService } from './Dayanna_Duran/serviciogeneral.service';
import { HttpClientModule } from '@angular/common/http'

@NgModule({
  declarations: [
    AppComponent,
    HomeAdministradorComponent,
    HomeEmpleadoComponent,
    Pagina404Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ServiciogeneralService],
  bootstrap: [AppComponent]
})
export class AppModule { }
