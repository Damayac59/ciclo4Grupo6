import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HomeAdministradorComponent } from './Dayanna_Duran/home-administrador/home-administrador.component';
import { HomeEmpleadoComponent } from './Dayanna_Duran/home-empleado/home-empleado.component';
import { Pagina404Component } from './Dayanna_Duran/pagina404/pagina404.component';
import { ServiciogeneralService } from './Dayanna_Duran/serviciogeneral.service';
import { HttpClientModule } from '@angular/common/http';
import { NuevoUsuarioComponent } from './JorgeRodriguez/nuevo-usuario/nuevo-usuario.component';
import { RegistroNovedadComponent } from './MafePinzon/registro-novedad/registro-novedad.component';
import { PaginaPrincipalComponent } from './DanielTesillo/pagina-principal/pagina-principal.component';
import { CrearNovedadesComponent } from './MafeOlaya/crear-novedades/crear-novedades.component';
import { EliminarNovedadComponent } from './MafeOlaya/eliminar-novedad/eliminar-novedad.component';
import { InformeEmpleadosComponent } from './Daniel_Fernando_Amaya_Cristancho/informe-empleados/informe-empleados.component';
import { ServicioNovedadService } from './MafeOlaya/servicio-novedad.service';


@NgModule({
  declarations: [
    AppComponent,
    HomeAdministradorComponent,
    HomeEmpleadoComponent,
    Pagina404Component,
    NuevoUsuarioComponent,
    RegistroNovedadComponent,
    PaginaPrincipalComponent,
    CrearNovedadesComponent,
    EliminarNovedadComponent,
    InformeEmpleadosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ServiciogeneralService, ServicioNovedadService],
  bootstrap: [AppComponent]
})
export class AppModule { }
