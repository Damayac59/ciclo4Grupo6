import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';
import { ServiciogeneralService } from '../serviciogeneral.service';

declare var anuncio:any;

@Component({
  selector: 'app-home-administrador',
  templateUrl: './home-administrador.component.html',
  styleUrls: ['./home-administrador.component.css']
})
export class HomeAdministradorComponent implements OnInit {

  anuncio(){
    alert("Bienvenido Administrador");
  };

  constructor(private APIService: ServiciogeneralService) { }

  
  ngOnInit(): void {
  }

}
