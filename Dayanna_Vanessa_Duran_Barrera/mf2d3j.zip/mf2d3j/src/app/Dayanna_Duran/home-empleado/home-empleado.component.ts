import { Component, OnInit } from '@angular/core';
declare var mensaje:any;

@Component({
  selector: 'app-home-empleado',
  templateUrl: './home-empleado.component.html',
  styleUrls: ['./home-empleado.component.css']
})
export class HomeEmpleadoComponent implements OnInit {

  mensaje(){};

  constructor() { }
   
  ngOnInit(): void {
  }

}
