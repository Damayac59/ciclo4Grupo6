import { ModuloNov } from './modulo-nov';

describe('ModuloNov', () => {
  it('should create an instance', () => {
    expect(new ModuloNov()).toBeTruthy();
  });
});
