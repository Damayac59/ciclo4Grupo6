//import * as internal from "stream";

export class ModuloNov {
  codigo_novedad!: number;
  nombre_novedad!: string;
  descripcion_novedad!:string;

  constructor(){}
}
